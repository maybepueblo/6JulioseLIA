# Afina tu propio LLM — taller seLIA 2026

Material del taller **«Afina tu propio LLM»** (seLIA 2026, URJC Fuenlabrada · Asociación de IA · OfiLibre).

Vas a **afinar (fine-tuning) un modelo de lenguaje abierto con tus propios datos**, en local y con software libre, usando **LoRA** sobre el stack estándar de Hugging Face (`transformers` + `peft`). Todo el proceso se instala y ejecuta **solo con `git` y `pip`**, sin conda ni permisos de administrador.

> Licencia del material: **CC BY-SA 4.0**.

---

## Requisitos

- **Python 3.10 – 3.12** (`python --version`).
- **GPU NVIDIA** con drivers CUDA instalados (`nvidia-smi` debe funcionar). En el aula las tienes.
- Acceso a **`git`** y **`pip`** (es lo único que necesitamos).
- Conexión de red para descargar librerías (pip) y el modelo (Hugging Face). Si la red está limitada, mira la sección *Sin conexión / modelos*.

---

## Vías posibles (y por qué elegimos esta)

| Vía                                     | Memoria GPU | Instalación con pip        | Notas                                                   |
| ---------------------------------------- | ----------- | --------------------------- | ------------------------------------------------------- |
| **LoRA 16-bit** *(por defecto)* | Media-alta  | La más sencilla y portable | Aprovechamos las GPUs                                   |
| **QLoRA 4-bit**                    | Baja        | Añade`bitsandbytes`      | Para GPUs con poca VRAM. Activa`LOAD_IN_4BIT = True`. |
| **Unsloth**                        | Baja        | Más frágil según CUDA    | Vía rápida (2× más veloz).                          |

Como el aula tiene **GPUs potentes**, el notebook va por defecto en **LoRA 16-bit**: es la opción **más robusta con `pip`** porque evita la cuantización (que es la dependencia que más problemas de instalación suele dar). Si te faltara memoria, el mismo notebook cambia a QLoRA 4-bit con un solo interruptor.

---

## Instalación (git + pip)

### 1. Clonar el repositorio

```bash
git clone <URL-del-repo>
cd afina-tu-llm
```

### 2. Crear un entorno virtual (solo `pip`, sin conda)

```bash
python -m venv .venv
# Linux / macOS:
source .venv/bin/activate
# Windows (PowerShell):
# .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

### 3. Instalar PyTorch **con soporte CUDA**

Elige el índice según la versión de CUDA que muestre `nvidia-smi` (arriba a la derecha):

```bash
# CUDA 12.1 (lo más habitual)
pip install torch --index-url https://download.pytorch.org/whl/cu121
# CUDA 11.8
# pip install torch --index-url https://download.pytorch.org/whl/cu118
# CUDA 12.4
# pip install torch --index-url https://download.pytorch.org/whl/cu124
```

> ⚠️ Si instalas `torch` sin `--index-url`, puede que caiga la versión **solo-CPU** y el entrenamiento vaya lentísimo. Comprueba el paso 5.

### 4. Instalar el resto de dependencias

```bash
pip install -r requirements.txt
```

### 5. Comprobar que la GPU se ve

```bash
python -c "import torch; print('CUDA:', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')"
# En caso de que esto dé problemas,  puede deberse a la gráfica tan actualizada que disponemos
# hacemos primero
pip uninstall torch torchvision torchaudio
# Para luego instalar las librerías actualizadas
pip install --pre torch torchvision torchaudio --index-url https://download.pytorch.org/whl/nightly/cu130
```

Debe decir `CUDA: True`. Si dice `False`, vuelve al paso 3 (índice de CUDA equivocado).

### 6. Abrir el notebook

```bash
jupyter lab            # o:  jupyter notebook
```

Abre **`afina_tu_llm.ipynb`** y ejecuta las celdas de arriba abajo.

**¿Sin interfaz gráfica / por SSH?** Ejecútalo entero desde la terminal:

```bash
jupyter nbconvert --to notebook --execute --inplace afina_tu_llm.ipynb
```

## Sin conexión / modelos

- El modelo por defecto es **`Qwen/Qwen2.5-1.5B-Instruct`**: abierto (Apache-2.0) y **sin *gate***, así que **no necesitas cuenta ni token** de Hugging Face.
- La primera ejecución descarga el modelo a la caché (`~/.cache/huggingface`). Puedes cambiarla con `export HF_HOME=/ruta/con/espacio`.
- Si Hugging Face está bloqueado pero **sí tienes `git`**, puedes bajar el modelo por git y apuntar el notebook a la carpeta local:
  ```bash
  git lfs install
  git clone https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct
  # y en el notebook:  MODELO = "./Qwen2.5-1.5B-Instruct"
  ```
- Modelos *gated* (p. ej. algunos Llama) requieren aceptar la licencia y `huggingface-cli login`. Por eso el taller usa Qwen (sin gate).

---

## Personalizar

Con todo el contenido del notebook se puede experimentar:

- **Paso 1** — `MODELO`: prueba `Qwen/Qwen2.5-3B-Instruct` o `google/gemma-2-2b-it` si te sobra VRAM. `LOAD_IN_4BIT`: ponlo a `True` para QLoRA.
- **Paso 4** — `EJEMPLOS`: **cambia los pares {instrucción → respuesta} por los tuyos**. Es lo que más impacto tiene. Regla de oro: *calidad > cantidad*.
- **Paso 5** — `num_train_epochs`, `learning_rate`, `r` del LoRA.

---

## Resolución de problemas

| Síntoma                                   | Causa probable         | Solución                                                                                                   |
| ------------------------------------------ | ---------------------- | ----------------------------------------------------------------------------------------------------------- |
| `torch.cuda.is_available()` → `False` | PyTorch CPU o CUDA mal | Reinstala torch con el`--index-url` correcto (paso 3).                                                    |
| `CUDA out of memory`                     | Modelo o batch grandes | `LOAD_IN_4BIT = True`, baja `MAX_LEN`, usa un modelo más pequeño o `per_device_train_batch_size=1`. |
| `bitsandbytes`… error                   | Solo aparece con 4-bit | `pip install bitsandbytes` (solo si usas QLoRA).                                                          |
| Descarga del modelo falla                  | Red / gate             | Usa Qwen (sin gate) o clónalo por git (arriba).                                                            |
| El modelo no cambia tras entrenar          | Pocos pasos            | Sube`num_train_epochs` o añade más ejemplos.                                                            |

---

## Contenido

```
afina-tu-llm/
├── afina_tu_llm.ipynb   # el taller, celda a celda
├── requirements.txt     # dependencias (pip)
└── README.md            # esto
```

## Licencia

Material del taller bajo **CC BY-SA 4.0**. Los modelos y librerías mantienen sus respectivas licencias abiertas.
